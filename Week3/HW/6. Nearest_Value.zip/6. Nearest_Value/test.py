import unittest
from nearest_value import nearest_value
import numpy as np


class TestMatrix(unittest.TestCase):
    def test1(self):
        X = np.array([[1, 2, 13],
                      [15, 6, 8],
                      [7, 18, 9]])
        a = 7.2
        expected = 7
        actual = nearest_value(X, a)
        self.assertEqual(expected, actual)

    def test2(self):
        X = np.array([[1, 2, 13],
                      [15, 6, 7.4],
                      [7, 18, 9]])
        a = 7.2
        expected = 7
        actual = nearest_value(X, a)
        self.assertEqual(expected, actual)


if __name__ == "__main__":
    unittest.main()
