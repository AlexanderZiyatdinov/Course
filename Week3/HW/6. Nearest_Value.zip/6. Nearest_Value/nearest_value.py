import numpy as np


def nearest_value(X: np.ndarray, a: float) -> np.float:
    ### ╰( ͡° ͜ʖ ͡° )つ──☆*:・ﾟ
    pass


if __name__ == "__main__":
    X = np.array([[1, 2, 13],
                  [15, 6, 8],
                  [7, 18, 9]])
    a = 7.2
    print(nearest_value(X, a))