# Подсказка: воспользуйся словарем и условиями!

def create_msg(symbol: str, amount: int) -> str:
    """Функия принимает два аргумента:
    symbol: str - символ d или r
    amount: int - количество денег

    Функция возвращает одно значение -
    строку вида '100 долларов', сохраняя склонение"""
    msg: str = ...  ### ╰( ͡° ͜ʖ ͡° )つ──☆*:・ﾟ
    return msg


if __name__ == "__main__":
    symbol = input()
    amount = int(input())
    print(create_msg(symbol, amount))
