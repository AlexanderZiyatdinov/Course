from dollar import create_msg
import unittest


class testDollarTask(unittest.TestCase):
    def test1(self):
        symbol = 'r'
        amount = 1
        actual = create_msg(symbol, amount)
        expected = '1 рубль'
        self.assertEqual(actual, expected)

    def test2(self):
        symbol = 'r'
        amount = 2
        actual = create_msg(symbol, amount)
        expected = '2 рубля'
        self.assertEqual(actual, expected)

    def test3(self):
        symbol = 'r'
        amount = 3
        actual = create_msg(symbol, amount)
        expected = '3 рубля'
        self.assertEqual(actual, expected)

    def test4(self):
        symbol = 'r'
        amount = 4
        actual = create_msg(symbol, amount)
        expected = '4 рубля'
        self.assertEqual(actual, expected)

    def test5(self):
        symbol = 'r'
        amount = 5
        actual = create_msg(symbol, amount)
        expected = '5 рублей'
        self.assertEqual(actual, expected)

    def test20(self):
        symbol = 'r'
        amount = 20
        actual = create_msg(symbol, amount)
        expected = '20 рублей'
        self.assertEqual(actual, expected)

    def test10(self):
        symbol = 'r'
        amount = 10
        actual = create_msg(symbol, amount)
        expected = '10 рублей'
        self.assertEqual(actual, expected)

    def test11(self):
        symbol = 'r'
        amount = 11
        actual = create_msg(symbol, amount)
        expected = '11 рублей'
        self.assertEqual(actual, expected)

    def test12(self):
        symbol = 'r'
        amount = 12
        actual = create_msg(symbol, amount)
        expected = '12 рублей'
        self.assertEqual(actual, expected)

    def test13(self):
        symbol = 'r'
        amount = 13
        actual = create_msg(symbol, amount)
        expected = '13 рублей'
        self.assertEqual(actual, expected)

    def test14(self):
        symbol = 'r'
        amount = 14
        actual = create_msg(symbol, amount)
        expected = '14 рублей'
        self.assertEqual(actual, expected)

    def test21(self):
        symbol = 'r'
        amount = 21
        actual = create_msg(symbol, amount)
        expected = '21 рубль'
        self.assertEqual(actual, expected)

    def test22(self):
        symbol = 'r'
        amount = 22
        actual = create_msg(symbol, amount)
        expected = '22 рубля'
        self.assertEqual(actual, expected)