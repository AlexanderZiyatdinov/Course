def should_fire(enemyInFront: bool, enemyName: str, robotHealth: int) -> bool:
    return ... # ╰( ͡° ͜ʖ ͡° )つ──☆*:・ﾟ
