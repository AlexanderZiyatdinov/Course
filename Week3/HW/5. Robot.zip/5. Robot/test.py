import unittest
import robot


class TestRobotTask(unittest.TestCase):
    def test1(self):
        expected = robot.should_fire(True, "boss", 40)
        actual = False
        self.assertEqual(actual, expected)

    def test2(self):
        expected = robot.should_fire(True, "boss", 60)
        actual = True
        self.assertEqual(actual, expected)

    def test3(self):
        expected = robot.should_fire(True, "boss", 50)
        actual = True
        self.assertEqual(actual, expected)

    def test4(self):
        expected = robot.should_fire(True, "enemy", 50)
        actual = True
        self.assertEqual(actual, expected)

    def test5(self):
        expected = robot.should_fire(True, "enemy", 40)
        actual = True
        self.assertEqual(actual, expected)

    def test6(self):
        expected = robot.should_fire(True, "enemy", 60)
        actual = True
        self.assertEqual(actual, expected)

    def test7(self):
        expected = robot.should_fire(False, "boss", 40)
        actual = False
        self.assertEqual(actual, expected)

    def test8(self):
        expected = robot.should_fire(False, "boss", 60)
        actual = False
        self.assertEqual(actual, expected)

    def test9(self):
        expected = robot.should_fire(False, "boss", 50)
        actual = False
        self.assertEqual(actual, expected)

    def test10(self):
        expected = robot.should_fire(False, "enemy", 50)
        actual = False
        self.assertEqual(actual, expected)

    def test11(self):
        expected = robot.should_fire(False, "enemy", 40)
        actual = False
        self.assertEqual(actual, expected)

    def test12(self):
        expected = robot.should_fire(False, "enemy", 60)
        actual = False
        self.assertEqual(actual, expected)
