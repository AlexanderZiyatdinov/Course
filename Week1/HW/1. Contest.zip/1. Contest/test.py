import unittest
import Contest


class TestContestTask(unittest.TestCase):
    def test1(self):
        num1 = 5
        num2 = 3
        expected = 5
        actual = Contest.contest(num1, num2)
        self.assertEqual(actual, expected)

    def test2(self):
        num1 = 3
        num2 = 5
        expected = 5
        actual = Contest.contest(num1, num2)
        self.assertEqual(actual, expected)

    def test3(self):
        num1 = 5
        num2 = 5
        expected = 5
        actual = Contest.contest(num1, num2)
        self.assertEqual(actual, expected)
