def contest(num1: int, num2: int) -> int:
    max_num: int = ...  # ╰( ͡° ͜ʖ ͡° )つ──☆*:・ﾟ
    return max_num


if __name__ == "__main__":
    num1: int = int(input())
    num2: int = int(input())
    print(contest(num1, num2))
