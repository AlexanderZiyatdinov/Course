import unittest
import Bad_Piggies


class TestBadPiggiesTask(unittest.TestCase):
    def test1(self):
        dist = 10
        v = 10
        expected = 0.6852307422358885
        actual = Bad_Piggies.bad_piggies(dist, v)
        assert abs(actual - expected) < 0.01

    def test2(self):
        dist = 1
        v = 10
        expected = 0.04907877358750136
        actual = Bad_Piggies.bad_piggies(dist, v)
        assert abs(actual - expected) < 0.01

    def test3(self):
        dist = 0
        v = 10
        expected = 0
        actual = Bad_Piggies.bad_piggies(dist, v)
        assert abs(actual - expected) < 0.01

