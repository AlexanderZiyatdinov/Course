import math
import unittest
import Geometry
from Vector import Vector


class TestGeometryTask(unittest.TestCase):
    def testAngle1(self):
        vec1 = Vector(1, 1, 1)
        vec2 = Vector(2, 2, 2)
        expected = 1
        actual = Geometry.cos_between_vectors(vec1, vec2)
        assert abs(expected - actual) < .1

    def testAngle2(self):
        vec1 = Vector(1, 1, 1)
        vec2 = Vector(-1, -1, -1)
        expected = -1
        actual = Geometry.cos_between_vectors(vec1, vec2)
        assert abs(expected - actual) < .1

    def testAngle3(self):
        vec1 = Vector(1, 0, 0)
        vec2 = Vector(0, 0, 1)
        expected = 0
        actual = Geometry.cos_between_vectors(vec1, vec2)
        assert abs(expected - actual) < .1

    def testAngle4(self):
        vec1 = Vector(1, 2, 3)
        vec2 = Vector(3, 2, 1)
        expected = 0.7142857142857143
        actual = Geometry.cos_between_vectors(vec1, vec2)
        assert abs(expected - actual) < .1

    def testScalarProduct1(self):
        vec1 = Vector(1, 1, 1)
        vec2 = Vector(3, 2, 1)
        expected = 6
        actual = Geometry.scalar_product(vec1, vec2)
        assert abs(expected - actual) < .1

    def testScalarProduct2(self):
        vec1 = Vector(1, 2, 3)
        vec2 = Vector(3, 2, 1)
        expected = 10
        actual = Geometry.scalar_product(vec1, vec2)
        assert abs(expected - actual) < .1

