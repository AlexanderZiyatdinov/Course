import math
from Vector import Vector


def cos_between_vectors(vector1: Vector, vector2: Vector) -> float:
    cos = ...  # ╰( ͡° ͜ʖ ͡° )つ──☆*:・ﾟ
    return cos


def scalar_product(vector1: Vector, vector2: Vector) -> float:
    result = ...  # ╰( ͡° ͜ʖ ͡° )つ──☆*:・ﾟ
    return result


if __name__ == "__main__":
    vector1 = Vector(0, 3, 4)  # Можете менять координаты
    vector2 = Vector(3, 4, 0)  # Можете менять координаты

    print(cos_between_vectors(vector1, vector2))
    print(scalar_product(vector1, vector2))

