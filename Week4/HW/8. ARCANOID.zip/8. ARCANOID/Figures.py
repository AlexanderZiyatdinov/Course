import pygame
from pygame import Rect


class Platform(Rect):
    """Создает объект - Платформа
    Принимает четыре аргумента:
    top: float Координата по y
    left: float Координата по x
    width: float Ширина платформы в px
    height: float Высота платформы в px
    """

    def __init__(self, top, left, width, height):
        super().__init__(top, left, width, height)
        self.speed = 15  # Скорость движения платформы
    pass


class Ball(Rect):
    """Создает объект - Шар
    Принимает четыре аргумента:
    top: float Координата по y
    left: float Координата по x
    width: float Ширина шара в px
    height: float Высота шара в px
    """

    def __init__(self, top, left, width, height):
        super().__init__(top, left, width, height)
        self.speed = 6  # Скорость движения шара
    pass


class Block(Rect):
    """Создает объект - Блок
    Принимает четыре аргумента:
    top: float Координата по y
    left: float Координата по x
    width: float Ширина блока в px
    height: float Высота блока в px
    """
