import towns

# Ваша задача:
# Расположить всех существ по своим городам и по своим уровням
# Пользуйтесь статьей: https://homm3sod.ru/units/


castle = towns.castle
rampart = towns.rampart
tower = towns.tower
inferno = towns.inferno
necropolis = towns.necropolis
dungeon = towns.dungeon
stronghold = towns.stronghold
fortress = towns.fortress
conflux = towns.conflux

# TODO поправьте каждый город!
# Ваш код напишите ниже: ╰( ͡° ͜ʖ ͡° )つ──☆*:・ﾟ
