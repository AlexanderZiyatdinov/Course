import HoMM3
import unittest
import webbrowser


class TestHoMMTask(unittest.TestCase):
    def testCastle(self):
        expected = ['Алебардщик', 'Стрелок', 'Королевский грифон', 'Крестоносец',
             'Фанатик', 'Чемпион', 'Архангел']
        actual = HoMM3.castle
        self.assertEqual(expected, actual)

    def testRampart(self):
        expected = ['Командир кентавров',
             'Боевой гном', 'Великий эльф', 'Серебряный пегас',
             'Дендроид солдат', 'Боевой единорог', 'Золотой дракон']
        actual = HoMM3.rampart
        self.assertEqual(expected, actual)

    def testTower(self):
        expected = ['Местер Гремлин', 'Обсидиановая гаргулья', 'Железный голем',
             'Архи-маг', 'Мастер джин', 'Королева Нага', 'Титан']
        actual = HoMM3.tower
        self.assertEqual(expected, actual)

    def testInferno(self):
        expected = ['Черт', 'Магог', 'Цербер', 'Рогатый демон',
             'Адское отродье', 'Султан Эфрит', 'Архидьявол']
        actual = HoMM3.inferno
        self.assertEqual(expected, actual)

    def testNecropolis(self):
        expected = ['Скелет воин', 'Зомби', 'Привидение', 'Вампир - лорд',
             'Архи-Лич', 'Рыцарь смерти', 'Дракон-Призрак']
        actual = HoMM3.necropolis
        self.assertEqual(expected, actual)

    def testDungeon(self):
        expected = ['Адский троглодит', 'Гарпия ведьма', 'Злые глаза',
             'Королева медуза', 'Король - минотавр', 'Скорпикора',
             'Черный дракон']
        actual = HoMM3.dungeon
        self.assertEqual(expected, actual)

    def testStronghold(self):
        expected = ['Хобгоблин', 'Налетчик',
             'Орк - вождь', 'Людоед - Маг', 'Птица грома', 'Король циклопов',
             'Древнее чудище']
        actual = HoMM3.stronghold
        self.assertEqual(expected, actual)

    def testFortress(self):
        expected = ['Гнолл - мародер',
             'Ящер - воин', 'Стрекоза', 'Великий василиск', 'Могучая горгона',
             'Виверна - монарх', 'Гидра хаоса']
        actual = HoMM3.fortress
        self.assertEqual(expected, actual)

    def testConflux(self):
        expected = ['Фея', 'Элементаль шторма', 'Ледяной элементаль',
             'Энергетический элементаль', 'Элементаль магмы',
             'Магический элементаль', 'Феникс']
        actual = HoMM3.conflux
        self.assertEqual(expected, actual)

    def testAll(self):
        expected = ['Алебардщик', 'Стрелок', 'Королевский грифон', 'Крестоносец',
             'Фанатик', 'Чемпион', 'Архангел', 'Командир кентавров',
             'Боевой гном', 'Великий эльф', 'Серебряный пегас',
             'Дендроид солдат', 'Боевой единорог', 'Золотой дракон',
             'Местер Гремлин', 'Обсидиановая гаргулья', 'Железный голем',
             'Архи-маг', 'Мастер джин', 'Королева Нага', 'Титан','Черт',
             'Магог', 'Цербер', 'Рогатый демон',
             'Адское отродье', 'Султан Эфрит', 'Архидьявол',
             'Скелет воин', 'Зомби', 'Привидение', 'Вампир - лорд',
             'Архи-Лич', 'Рыцарь смерти', 'Дракон-Призрак',
             'Адский троглодит', 'Гарпия ведьма', 'Злые глаза',
             'Королева медуза', 'Король - минотавр', 'Скорпикора',
             'Черный дракон','Хобгоблин', 'Налетчик',
             'Орк - вождь', 'Людоед - Маг', 'Птица грома', 'Король циклопов',
             'Древнее чудище', 'Гнолл - мародер',
             'Ящер - воин', 'Стрекоза', 'Великий василиск', 'Могучая горгона',
             'Виверна - монарх', 'Гидра хаоса', 'Фея', 'Элементаль шторма',
             'Ледяной элементаль', 'Энергетический элементаль',
             'Элементаль магмы', 'Магический элементаль', 'Феникс']
        actual = (HoMM3.castle + HoMM3.rampart + HoMM3.tower + HoMM3.inferno +
                  HoMM3.necropolis + HoMM3.dungeon + HoMM3.stronghold +
                  HoMM3.fortress + HoMM3.conflux)

        if expected == actual:
            webbrowser.open('https://www.youtube.com/watch?v=vdJRKWfzpuA', new=2)
        self.assertEqual(expected, actual)