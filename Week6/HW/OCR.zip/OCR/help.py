import cv2
import pytesseract
pytesseract.pytesseract.tesseract_cmd = r'Тут путь до файла'


def ocr(filename):
    pass


if __name__ == "__main__":
    pass

