import help
import unittest

actual: str = help.ocr('img1.png')
print(actual)


class TestHelp(unittest.TestCase):
    def test1(self):
        expected: str = """Split text with\nmultiple delimiters"""
        actual: str = help.ocr('img1.png')
        print(actual)
        self.assertEqual(expected.lower().split('\n')[0],
                                         actual.lower().split('\n')[0])


if __name__ == "__main__":
    unittest.main()
